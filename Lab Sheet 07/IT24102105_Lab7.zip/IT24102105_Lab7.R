setwd("C:\\Users\\Pentiumcity\\Desktop\\IT24102105")
getwd()

# Question 1
# Uniform distribution from 0 to 40 minutes.
# Probability that X is between 10 and 25 minutes:
punif(25, min=0, max=40) - punif(10, min=0, max=40)


# Question 2
# Exponential with rate lambda = 1/3 (hours^-1).
# P(X <= 2) for Exp(lambda):
pexp(2, rate=1/3)


# Question 3
# IQ ~ N(mean=100, sd=15)
# (i) P(IQ > 130)
1 - pnorm(130, mean=100, sd=15)

# (ii) 95th percentile
qnorm(0.95, mean=100, sd=15)
